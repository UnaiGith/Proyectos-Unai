from abc import ABC, abstractmethod
from enum import StrEnum
# noinspection PyUnresolvedReferences,PyProtectedMember
from typing import override


# region ------------ Weapon classes ------------

class Weapon(ABC):
    """Abstract class for weapons."""

    def __init__(self, name: str, short_range: bool, damage: int, num_uses: int = 3):
        self.name = name
        self.short_range = short_range
        self.damage = damage
        self.num_uses = num_uses

    def attack(self, attacker: 'Character', target: 'Character') -> None:
        """Perform an attack with this weapon."""
        if target.hp <= 0:  # Target is already dead
            print(f"{target.name} is dead! Cannot attack.\n")
            return

        if self.num_uses <= 0:  # Weapon is broken
            if self.num_uses == 0:  # First time it breaks
                print(f"{self.name} broke! It has no more uses.")
                self.num_uses -= 1
            else:  # Already broken
                print(f"{self.name} is broken! Cannot attack.")
            return

        # Perform the attack
        print(f"{attacker.name} attacks {target.name} with {self.name}")
        self.attack_sound()  # Play attack sound
        print(f"{target.name} received {self.damage} points of damage -> {target.name} HP={max(0, target.hp - self.damage)}")

        target.reduce_health(self.damage)
        self.num_uses -= 1  # Reduce weapon uses

    @abstractmethod
    def attack_sound(self) -> None:
        pass

    def __str__(self):
        range_type = "short" if self.short_range else "long"
        return f"{self.name}(range={range_type}, damage={self.damage}, num_uses={self.num_uses})"

    def __repr__(self):
        return f"{self.name}()"


class Sword(Weapon):
    SHORT_RANGE = True
    DAMAGE = 25
    NUM_USES = 5

    def __init__(self):
        super().__init__(self.__class__.__name__, self.SHORT_RANGE, self.DAMAGE, self.NUM_USES)

    @override
    def attack_sound(self) -> None:
        print('Swish!')
        print('Slash!')


class Axe(Weapon):
    SHORT_RANGE = True
    DAMAGE = 40
    NUM_USES = 3

    def __init__(self):
        super().__init__(self.__class__.__name__, self.SHORT_RANGE, self.DAMAGE, self.NUM_USES)

    @override
    def attack_sound(self) -> None:
        print('Chop!')


class Bow(Weapon):
    SHORT_RANGE = False
    DAMAGE = 15
    NUM_USES = 10

    def __init__(self):
        super().__init__(self.__class__.__name__, self.SHORT_RANGE, self.DAMAGE, self.NUM_USES)

    @override
    def attack_sound(self) -> None:
        print('Creak...')
        print('Twang!')
        print('Thud!')


# endregion

# region ------------ Character classes ------------

class Race(StrEnum):
    """Enumeration of races."""
    ELF = "elf"
    DWARF = "dwarf"
    ORC = "orc"
    TROLL = "troll"

    def __repr__(self):
        return f'{self.__class__.__name__}.{self.name}'


class Character(ABC):
    """Abstract class for characters."""
    INITIAL_HP = 100

    def __init__(self, name: str, weapon: 'Weapon'):
        self.hp = self.INITIAL_HP
        self.name = name
        self.weapon = weapon

    def attack(self, target: 'Character') -> None:
        """Attack another character using the equipped weapon."""
        self.weapon.attack(self, target)

    def reduce_health(self, damage: int) -> None:
        """Reduce the character's health."""
        self.hp = max(0, self.hp - damage)
        if self.hp == 0:
            print(f"{self.name} has died!")

    def is_alive(self) -> bool:
        """Check if the character is alive."""
        return self.hp > 0

    def __repr__(self):
        """Return an unambiguous string representation of the character."""
        return f"<{self.__class__.__name__}(name={self.name}, hp={self.hp}, weapon={repr(self.weapon)})>"

    def __str__(self):
        """Return a readable string representation of the character."""
        return f"{self.name} (HP: {self.hp}, Weapon: {self.weapon})"


class Enemy(Character):
    def __init__(self, name: str, weapon: Weapon, race: Race):
        super().__init__(name, weapon)
        self.race = race

    def __repr__(self):
        return f"Enemy(name=\"{self.name}\", weapon={repr(self.weapon)}, race={repr(self.race)})"

    def __str__(self):
        return f"[{self.race.value}] {self.name}(HP={self.hp}, alive={self.is_alive()}, weapon={self.weapon})"


class Player(Character):
    def __init__(self, name: str, weapon: Weapon):
        super().__init__(name, weapon)

    def __repr__(self):
        return f"Player(name=\"{self.name}\", weapon={repr(self.weapon)})"

    def __str__(self):
        return f"[player] {self.name}(HP={self.hp}, alive={self.is_alive()}, weapon={self.weapon})"


# endregion

# region ------------ Main ------------

def execute_battle(interactive=True) -> None:
    # Create characters
    player = Player('Dovahkiin', Sword())
    dwarf = Enemy('Gimli', Axe(), Race.DWARF)
    elf = Enemy('Legolas', Bow(), Race.ELF)
    orc = Enemy('Garrosh', Sword(), Race.ORC)
    troll = Enemy('Thokk', Axe(), Race.TROLL)

    # Print characters
    print(repr(player), repr(dwarf), repr(elf), repr(orc), repr(troll), '', sep='\n')
    print(player, dwarf, elf, orc, troll, '', sep='\n')

    ask_for_user_input(interactive)

    # Player attacks enemies
    print('\u2013\u2013\u2013\u2013\u2013\u2013\u2013 Player attacks enemies \u2013\u2013\u2013\u2013\u2013\u2013\u2013\n')
    player.attack(dwarf)
    player.attack(elf)
    player.attack(orc)
    player.attack(troll)

    ask_for_user_input(interactive)

    # Some enemies attack player
    print('\u2013\u2013\u2013\u2013\u2013\u2013\u2013 Some enemies attack player \u2013\u2013\u2013\u2013\u2013\u2013\u2013\n')
    dwarf.attack(player)
    elf.attack(player)

    ask_for_user_input(interactive)

    # Enemies attack each other
    print('\u2013\u2013\u2013\u2013\u2013\u2013\u2013 Enemies attack each other \u2013\u2013\u2013\u2013\u2013\u2013\u2013\n')
    elf.attack(dwarf)
    elf.attack(dwarf)
    dwarf.attack(elf)
    orc.attack(troll)
    troll.attack(orc)

    ask_for_user_input(interactive)

    # The dwarf dies
    print('\u2013\u2013\u2013\u2013\u2013\u2013\u2013 The dwarf dies \u2013\u2013\u2013\u2013\u2013\u2013\u2013\n')
    print(f'Is the dwarf {dwarf.name} still alive? {dwarf.is_alive()}\n')
    player.attack(dwarf)
    player.attack(dwarf)
    orc.attack(dwarf)
    print(f'Is the dwarf {dwarf.name} still alive? {dwarf.is_alive()}\n')
    dwarf.attack(player)

    ask_for_user_input(interactive)

    # Elf and orc trigger a mine and die
    print('\u2013\u2013\u2013\u2013\u2013\u2013\u2013 Elf and orc trigger a mine and die \u2013\u2013\u2013\u2013\u2013\u2013\u2013\n')
    print('The orc and elf encountered a mine, triggering a powerful explosion!\n')
    elf.reduce_health(50)
    orc.reduce_health(50)
    print('\nCharacters status:\n')
    print(player, dwarf, elf, orc, troll, '', sep='\n')

    ask_for_user_input(interactive)

    # Final battle
    print('\u2013\u2013\u2013\u2013\u2013\u2013\u2013 Final battle \u2013\u2013\u2013\u2013\u2013\u2013\u2013\n')
    print(f'{player.name} and {troll.name} engage in a fierce battle!\n')
    player.attack(troll)
    troll.attack(player)
    print(f'{player.name} surrenders and {troll.name} finishes him off!\n')
    troll.attack(player)
    print('Game over! Player lost the battle... :(')

def ask_for_user_input(interactive: bool) -> None:
    """Ask for user input to continue if interactive mode is enabled."""
    if interactive:
        input('Press Enter to continue...\n')


if __name__ == '__main__':
    execute_battle()

# endregion
